package entity;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * holds the data for the recipes that can be made using our machine
 * @author aakarsh
 *
 */
public class Recipes {
	
	/**
	 * recipe list of all beverages
	 */
	private static Map<String, Map<String, Integer>> menu = new HashMap<>();
	
	
	/**
	 * method to add new recipes in the menu
	 * @param node list all the recipes in menu
	 */
	public static void addRecipes(JsonNode node) {
		var breverageListIterator = node.fields();
		while(breverageListIterator.hasNext()) {
			Map<String, Integer> map = new HashMap<>();
			var breverageItem = breverageListIterator.next();
			var breverageIncredientsIterator = breverageItem.getValue().fields();
			while(breverageIncredientsIterator.hasNext()) {
				var incredient = breverageIncredientsIterator.next();
				map.put(incredient.getKey(), incredient.getValue().asInt());
			}
			menu.put(breverageItem.getKey(), map);
		}
	}
	
	
	/**
	 * given the input of the name of the drink, it returns the recipe to make the drink
	 * @param dish dish for with the recipe is required
	 * @return returns the drink to be prepared
	 */
	public static Map<String, Integer> getRecipe(String dish){
		return menu.getOrDefault(dish, null);
	}
}
