package bootup;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


import entity.Dispatcher;
import entity.EntityManager;
import entity.Recipes;

/**
 * This class is the handling point of our machine
 * All the interfaces for human interaction are provided here
 * @author aakarsh
 *
 */
public class Initializer {
	
	ExecutorService executorService;
	
	
	/**
	 * This class takes input for initial configuration of the system
	 * @see Recipes
	 * @see Initializer#populateIncredients(JsonNode)
	 * @see ExecutorService
	 * @param node input json
	 */
	public void initialize(JsonNode node) {
		
		// pulling up incredients
		var incredients = node.get("machine").get("total_items_quantity");
		this.populateIncredients(incredients);
		
		//registering the recipes
		Recipes.addRecipes(node.at("/machine/beverages"));
		
		
		//Creating Multiple Threads
		int threads = node.at("/machine/outlets/count_n").asInt();
		executorService = Executors.newFixedThreadPool(threads);
	}
	
	/**
	 * This method is responsible for preparing the drinks parallelly and asynchronously
	 * by calling the threads using callables. In takes List of Strings as input 
	 * indicating the drinks that needs to be prepared in parallel.
	 * 
	 * @see Dispatcher
	 * 
	 * @param drinks list of all drinks that needs to be prepared in parallel
	 * @return the status if drinks completion
	 */
	public List<String> prepareDrink(List<String> drinks) {
		List<String> ans = new ArrayList<>();

		try {
			
			List<Callable<String>> tasks = new ArrayList<>();
			drinks.parallelStream()
				.forEach(bev -> tasks.add(new Dispatcher(bev)));
			List<Future<String>> futures = executorService.invokeAll(tasks);
			for(var future : futures) {
				ans.add(future.get());
			}
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return ans;
	}
	
	/**
	 * This method helps us repopulate the ingredients
	 * in the EntityManager
	 * @see EntityManager
	 * @param node new upadted list of all ingredients 
	 */
	public void populateIncredients(JsonNode node) {
		var incredients = node.fields();
		Map<String, Integer> increMap = new HashMap<>();
		while(incredients.hasNext()) {
			Map.Entry<String, JsonNode> temp = incredients.next();
			increMap.put(temp.getKey(), temp.getValue().asInt());
		}
		EntityManager entityManager = EntityManager.getInstance();
		entityManager.populateIncredients(increMap);
	}
}
