package entity;

import java.util.Map;

/**
 * This class validates if the drink asked is present in the menu and if is present,
 * then it tries to make the recipe
 * @author aakarsh
 *
 */
public class Cook {
	public Cook() {	
	}
	
	/**
	 * the prepare method
	 * @param beverage drink to be made
	 * @return returns if the drink can be made 
	 */
	public String prepare(String beverage){
		String ans = null;
		final Map<String, Integer> recipe = Recipes.getRecipe(beverage);
		if(recipe == null) {
			return beverage + ": not in the menu";
		}
		ans = EntityManager.getInstance().computeDrink(recipe);
		return beverage + " : " + ans;
	}
	
	
}
