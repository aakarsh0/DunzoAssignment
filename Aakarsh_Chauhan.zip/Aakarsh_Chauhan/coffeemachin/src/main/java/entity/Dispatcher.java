package entity;

import java.util.concurrent.Callable;

/**
 * callable interface for preparing the beverage
 * 
 * @see Callable
 * @author aakarsh
 *
 */
public class Dispatcher implements Callable<String> {
	String beverage;
	Cook cook;
	public Dispatcher(String beverage) {
		this.beverage = beverage;
		this.cook = new Cook();
	}

	@Override
	public String call() throws Exception {
		return cook.prepare(beverage);
	}
	
}
